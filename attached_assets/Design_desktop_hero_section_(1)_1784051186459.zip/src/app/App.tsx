import { useState } from "react";
import {
  LayoutDashboard,
  Users,
  BarChart3,
  Settings,
  Bell,
  Search,
  ChevronUp,
  ChevronDown,
  Play,
  Pause,
  Volume2,
  Maximize2,
  ArrowRight,
  Zap,
} from "lucide-react";

const WIN_DOTS = () => (
  <div className="flex gap-[5px] items-center flex-shrink-0">
    <div className="w-[10px] h-[10px] rounded-full bg-[#ff5f57] border border-black/10" />
    <div className="w-[10px] h-[10px] rounded-full bg-[#ffbd2e] border border-black/10" />
    <div className="w-[10px] h-[10px] rounded-full bg-[#28c840] border border-black/10" />
  </div>
);

const WindowChrome = ({ title, right }: { title?: string; right?: React.ReactNode }) => (
  <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-black/[0.06]" style={{ background: "#fafafa" }}>
    <div className="flex items-center gap-2.5">
      <WIN_DOTS />
      {title && (
        <span className="text-[11px] font-medium tracking-wide ml-1" style={{ color: "rgba(0,0,0,0.3)", fontFamily: "DM Sans, sans-serif" }}>
          {title}
        </span>
      )}
    </div>
    {right}
  </div>
);

const MetricCard = ({ label, value, delta, up }: { label: string; value: string; delta: string; up: boolean }) => (
  <div className="rounded-lg p-3 flex flex-col gap-1" style={{ background: "#f7f7fc", border: "1px solid rgba(0,0,0,0.07)" }}>
    <span className="text-[10px] font-medium tracking-wide uppercase" style={{ color: "rgba(0,0,0,0.35)", fontFamily: "DM Sans, sans-serif" }}>
      {label}
    </span>
    <span className="text-lg font-semibold" style={{ color: "#111219", fontFamily: "Bricolage Grotesque, sans-serif" }}>
      {value}
    </span>
    <div className="flex items-center gap-1">
      {up ? <ChevronUp className="w-3 h-3 text-emerald-500" /> : <ChevronDown className="w-3 h-3 text-rose-500" />}
      <span className={`text-[10px] font-medium ${up ? "text-emerald-600" : "text-rose-500"}`}>{delta}</span>
    </div>
  </div>
);

const BarMini = ({ h, active }: { h: number; active?: boolean }) => (
  <div className="w-[5px] rounded-sm flex-shrink-0" style={{ height: `${h}px`, background: active ? "#6366f1" : "rgba(0,0,0,0.1)" }} />
);

const CHART_DATA = [18, 24, 16, 32, 28, 38, 22, 42, 36, 48, 40, 54, 46, 58, 52, 62, 55, 70, 60, 72];

const MainDashboard = () => {
  const [activeNav, setActiveNav] = useState("dashboard");
  const navItems = [
    { id: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { id: "people", icon: Users, label: "People" },
    { id: "analytics", icon: BarChart3, label: "Analytics" },
    { id: "settings", icon: Settings, label: "Settings" },
  ];

  const records = [
    { name: "Stripe", status: "Active", mrr: "$12,400", stage: "Closed Won", dot: "bg-emerald-400" },
    { name: "Linear", status: "Trial", mrr: "$3,200", stage: "Negotiation", dot: "bg-amber-400" },
    { name: "Vercel", status: "Active", mrr: "$8,100", stage: "Closed Won", dot: "bg-emerald-400" },
    { name: "Resend", status: "Churned", mrr: "$0", stage: "Lost", dot: "bg-red-400" },
    { name: "Turso", status: "Trial", mrr: "$1,600", stage: "Proposal", dot: "bg-blue-400" },
  ];

  return (
    <div
      className="rounded-2xl overflow-hidden flex flex-col"
      style={{
        width: 680,
        height: 440,
        background: "#ffffff",
        border: "1px solid rgba(0,0,0,0.09)",
        boxShadow: "0 24px 64px rgba(0,0,0,0.1), 0 4px 16px rgba(0,0,0,0.06), 0 0 0 1px rgba(0,0,0,0.04)",
      }}
    >
      {/* Top bar */}
      <WindowChrome
        title="Basepoint"
        right={
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px]" style={{ background: "rgba(0,0,0,0.05)", color: "rgba(0,0,0,0.35)", fontFamily: "DM Sans, sans-serif" }}>
              <Search className="w-3 h-3" />
              Search…
            </div>
            <div className="w-6 h-6 rounded-full bg-indigo-500 flex items-center justify-center text-[10px] font-semibold text-white">
              JK
            </div>
          </div>
        }
      />

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="flex flex-col gap-0.5 py-3 px-2 border-r border-black/[0.06]" style={{ width: 52, background: "#fafafa" }}>
          {navItems.map(({ id, icon: Icon, label }) => (
            <button
              key={id}
              onClick={() => setActiveNav(id)}
              title={label}
              className="flex items-center justify-center w-8 h-8 rounded-lg transition-all"
              style={{
                background: activeNav === id ? "rgba(99,102,241,0.12)" : "transparent",
                color: activeNav === id ? "#6366f1" : "rgba(0,0,0,0.3)",
              }}
            >
              <Icon className="w-[15px] h-[15px]" />
            </button>
          ))}
          <div className="flex-1" />
          <div className="relative mx-auto">
            <Bell className="w-[15px] h-[15px]" style={{ color: "rgba(0,0,0,0.3)" }} />
            <div className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-indigo-500 border-2 border-[#fafafa]" />
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 overflow-hidden flex flex-col bg-white">
          {/* Metrics row */}
          <div className="grid grid-cols-4 gap-2 p-3">
            <MetricCard label="MRR" value="$24.1k" delta="+18% mo" up={true} />
            <MetricCard label="Active Accounts" value="1,284" delta="+94 wk" up={true} />
            <MetricCard label="Churn Rate" value="2.4%" delta="+0.3%" up={false} />
            <MetricCard label="NPS Score" value="68" delta="+4 pts" up={true} />
          </div>

          {/* Chart + table */}
          <div className="flex gap-2 px-3 pb-3 flex-1 overflow-hidden">
            {/* Chart */}
            <div className="flex flex-col flex-shrink-0 rounded-lg p-3 gap-2" style={{ width: 200, background: "#f7f7fc", border: "1px solid rgba(0,0,0,0.07)" }}>
              <span className="text-[10px] font-medium uppercase tracking-wide" style={{ color: "rgba(0,0,0,0.3)", fontFamily: "DM Sans, sans-serif" }}>
                Revenue trend
              </span>
              <div className="flex items-end gap-[3px] h-16 mt-auto">
                {CHART_DATA.map((h, i) => (
                  <BarMini key={i} h={Math.round((h / 72) * 56 + 8)} active={i >= 14} />
                ))}
              </div>
              <div className="flex justify-between">
                <span className="text-[9px]" style={{ color: "rgba(0,0,0,0.25)", fontFamily: "JetBrains Mono, monospace" }}>Jan</span>
                <span className="text-[9px]" style={{ color: "rgba(0,0,0,0.25)", fontFamily: "JetBrains Mono, monospace" }}>Jul</span>
              </div>
            </div>

            {/* Table */}
            <div className="flex-1 overflow-hidden flex flex-col" style={{ minWidth: 0 }}>
              <div className="grid text-[9px] font-medium uppercase tracking-wider px-2 pb-1.5" style={{ color: "rgba(0,0,0,0.28)", gridTemplateColumns: "1fr 60px 64px 80px", fontFamily: "DM Sans, sans-serif" }}>
                <span>Company</span>
                <span>Status</span>
                <span>MRR</span>
                <span>Stage</span>
              </div>
              <div className="flex flex-col gap-0.5 overflow-hidden">
                {records.map((r, i) => (
                  <div
                    key={i}
                    className="grid items-center px-2 py-1.5 rounded-md transition-colors hover:bg-black/[0.025] cursor-default"
                    style={{ gridTemplateColumns: "1fr 60px 64px 80px" }}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded-md bg-indigo-100 flex items-center justify-center text-[8px] font-bold text-indigo-500 flex-shrink-0">
                        {r.name[0]}
                      </div>
                      <span className="text-[11px] font-medium truncate" style={{ color: "#111219", fontFamily: "DM Sans, sans-serif" }}>{r.name}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className={`w-1.5 h-1.5 rounded-full ${r.dot}`} />
                      <span className="text-[10px]" style={{ color: "rgba(0,0,0,0.4)", fontFamily: "DM Sans, sans-serif" }}>{r.status}</span>
                    </div>
                    <span className="text-[10px] font-medium" style={{ color: "rgba(0,0,0,0.55)", fontFamily: "JetBrains Mono, monospace" }}>{r.mrr}</span>
                    <span
                      className="text-[9px] px-1.5 py-0.5 rounded w-fit"
                      style={{
                        background: r.stage === "Closed Won" ? "rgba(16,185,129,0.1)" : r.stage === "Lost" ? "rgba(239,68,68,0.1)" : "rgba(0,0,0,0.05)",
                        color: r.stage === "Closed Won" ? "#059669" : r.stage === "Lost" ? "#ef4444" : "rgba(0,0,0,0.4)",
                        fontFamily: "DM Sans, sans-serif",
                      }}
                    >
                      {r.stage}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ChatPanel = () => {
  const msgs = [
    { user: "Maya R.", avatar: "MR", color: "bg-violet-500", time: "9:41", text: "Just pushed the new onboarding flow — lmk if it looks good before we merge" },
    { user: "Tom G.", avatar: "TG", color: "bg-sky-500", time: "9:43", text: "Looks great! One thing — the empty state copy feels a bit generic" },
    { user: "Maya R.", avatar: "MR", color: "bg-violet-500", time: "9:44", text: "Good catch, I'll rewrite it. Can you tag the Figma frame?" },
    { user: "Priya S.", avatar: "PS", color: "bg-rose-500", time: "9:46", text: "Tagged — also flagged a contrast issue in the sidebar label 🙈" },
  ];

  return (
    <div
      className="rounded-xl overflow-hidden flex flex-col"
      style={{
        width: 248,
        background: "#ffffff",
        border: "1px solid rgba(0,0,0,0.08)",
        boxShadow: "0 12px 40px rgba(0,0,0,0.08), 0 2px 8px rgba(0,0,0,0.05)",
      }}
    >
      <WindowChrome
        title="# engineering"
        right={
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span className="text-[10px]" style={{ color: "rgba(0,0,0,0.3)", fontFamily: "DM Sans, sans-serif" }}>4 online</span>
          </div>
        }
      />
      <div className="flex flex-col gap-0 px-2 py-2 overflow-hidden flex-1">
        {msgs.map((m, i) => (
          <div key={i} className="flex gap-2 py-1.5">
            <div className={`w-6 h-6 rounded-full ${m.color} flex-shrink-0 flex items-center justify-center text-[8px] font-bold text-white`}>
              {m.avatar}
            </div>
            <div className="flex flex-col gap-0.5 min-w-0">
              <div className="flex items-baseline gap-1.5">
                <span className="text-[10px] font-semibold" style={{ color: "#111219", fontFamily: "DM Sans, sans-serif" }}>{m.user}</span>
                <span className="text-[9px]" style={{ color: "rgba(0,0,0,0.25)", fontFamily: "JetBrains Mono, monospace" }}>{m.time}</span>
              </div>
              <span className="text-[10px] leading-[1.45]" style={{ color: "rgba(0,0,0,0.45)", fontFamily: "DM Sans, sans-serif" }}>{m.text}</span>
            </div>
          </div>
        ))}
      </div>
      <div className="px-2.5 py-2 border-t border-black/[0.05] bg-[#fafafa]">
        <div className="flex-1 rounded-md px-2.5 py-1.5 text-[10px]" style={{ background: "rgba(0,0,0,0.04)", color: "rgba(0,0,0,0.3)", fontFamily: "DM Sans, sans-serif" }}>
          Message #engineering…
        </div>
      </div>
    </div>
  );
};

const TerminalPanel = () => {
  const lines = [
    { prompt: true, text: "git push origin feat/onboarding" },
    { prompt: false, text: "Enumerating objects: 12, done.", dim: true },
    { prompt: false, text: "Counting objects: 100% (12/12), done.", dim: true },
    { prompt: false, text: "Writing objects: 100% (7/7), 2.31 KiB | 2.31 MiB/s", dim: true },
    { prompt: false, text: "To github.com:acme/basepoint.git", dim: true },
    { prompt: false, text: "   a3f82c1..e0d14b7  feat/onboarding", green: true },
    { prompt: false, text: "" },
    { prompt: true, text: "npm run build", cursor: true },
  ];

  return (
    <div
      className="rounded-xl overflow-hidden flex flex-col"
      style={{
        width: 300,
        background: "#1a1b26",
        border: "1px solid rgba(0,0,0,0.15)",
        boxShadow: "0 12px 40px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.08)",
      }}
    >
      <div className="flex items-center px-3.5 py-2.5 border-b border-white/[0.07]" style={{ background: "#16172080" }}>
        <WIN_DOTS />
        <span className="text-[11px] font-medium tracking-wide ml-3" style={{ color: "rgba(255,255,255,0.28)", fontFamily: "DM Sans, sans-serif" }}>
          zsh — basepoint
        </span>
      </div>
      <div className="px-3 py-2.5 flex flex-col gap-0.5" style={{ fontFamily: "JetBrains Mono, monospace" }}>
        {lines.map((l, i) => (
          <div key={i} className="flex items-start gap-1.5">
            {l.prompt && (
              <span className="text-[10px] select-none flex-shrink-0" style={{ color: "#6366f1" }}>➜</span>
            )}
            <span
              className="text-[10px] leading-[1.6]"
              style={{
                color: (l as any).green ? "#4ade80" : (l as any).dim ? "rgba(255,255,255,0.22)" : l.prompt ? "rgba(255,255,255,0.78)" : "rgba(255,255,255,0.45)",
                whiteSpace: "pre-wrap",
              }}
            >
              {l.text}
              {l.cursor && (
                <span
                  className="inline-block w-[6px] h-[11px] align-middle ml-0.5"
                  style={{ background: "#6366f1", animation: "blink 1.1s step-end infinite" }}
                />
              )}
            </span>
          </div>
        ))}
      </div>
      <style>{`@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }`}</style>
    </div>
  );
};

const VideoPanel = () => {
  const [playing, setPlaying] = useState(false);
  const transcript = [
    { t: "0:00", text: "Welcome to Basepoint's Q3 product walkthrough." },
    { t: "0:12", text: "Today we'll cover the new CRM pipeline view and reporting dashboard." },
    { t: "0:28", text: "Starting with contact enrichment — now fully automated on import." },
    { t: "0:41", text: "You can see real-time firmographic data populating as we speak." },
    { t: "1:02", text: "Let's jump into the analytics panel and look at retention cohorts…" },
  ];

  return (
    <div
      className="rounded-xl overflow-hidden flex"
      style={{
        width: 310,
        height: 220,
        background: "#ffffff",
        border: "1px solid rgba(0,0,0,0.08)",
        boxShadow: "0 12px 40px rgba(0,0,0,0.08), 0 2px 8px rgba(0,0,0,0.05)",
      }}
    >
      {/* Video area */}
      <div className="flex flex-col" style={{ width: 180 }}>
        <div className="flex items-center px-3.5 py-2.5 border-b border-black/[0.06]" style={{ background: "#fafafa" }}>
          <WIN_DOTS />
          <span className="text-[11px] font-medium ml-2.5" style={{ color: "rgba(0,0,0,0.3)", fontFamily: "DM Sans, sans-serif" }}>Product Overview</span>
        </div>
        <div className="flex-1 relative flex items-center justify-center" style={{ background: "linear-gradient(135deg, #1e1f35 0%, #2d2060 100%)" }}>
          <div className="absolute inset-0 opacity-30" style={{ background: "radial-gradient(ellipse at 30% 60%, #6366f1 0%, transparent 60%)" }} />
          <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "linear-gradient(rgba(255,255,255,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.08) 1px, transparent 1px)", backgroundSize: "24px 24px" }} />
          <button
            onClick={() => setPlaying(!playing)}
            className="relative z-10 w-9 h-9 rounded-full flex items-center justify-center transition-all hover:scale-105"
            style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.2)", backdropFilter: "blur(8px)" }}
          >
            {playing ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white ml-0.5" />}
          </button>
          <div className="absolute bottom-0 left-0 right-0 px-2.5 py-2 flex items-center gap-2">
            <div className="flex-1 h-[3px] rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.15)" }}>
              <div className="h-full w-[28%] rounded-full" style={{ background: "#6366f1" }} />
            </div>
            <Volume2 className="w-3 h-3 flex-shrink-0" style={{ color: "rgba(255,255,255,0.35)" }} />
            <Maximize2 className="w-3 h-3 flex-shrink-0" style={{ color: "rgba(255,255,255,0.35)" }} />
          </div>
        </div>
        <div className="px-2.5 py-1.5 border-t border-black/[0.05] bg-[#fafafa]">
          <span className="text-[9px]" style={{ color: "rgba(0,0,0,0.3)", fontFamily: "JetBrains Mono, monospace" }}>1:02 / 4:38</span>
        </div>
      </div>

      {/* Transcript */}
      <div className="flex flex-col overflow-hidden" style={{ flex: 1, borderLeft: "1px solid rgba(0,0,0,0.06)" }}>
        <div className="px-2.5 py-2 border-b border-black/[0.05] bg-[#fafafa]">
          <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "rgba(0,0,0,0.3)", fontFamily: "DM Sans, sans-serif" }}>
            Transcript
          </span>
        </div>
        <div className="flex flex-col gap-0 px-2 py-2 overflow-hidden bg-white">
          {transcript.map((line, i) => (
            <div key={i} className="flex gap-2 py-1" style={{ borderLeft: i === 4 ? "2px solid #6366f1" : "2px solid transparent", paddingLeft: 6 }}>
              <span className="text-[9px] flex-shrink-0 mt-0.5" style={{ color: "#6366f1", fontFamily: "JetBrains Mono, monospace", width: 28 }}>
                {line.t}
              </span>
              <span className="text-[9px] leading-[1.5]" style={{ color: i === 4 ? "rgba(0,0,0,0.65)" : "rgba(0,0,0,0.35)", fontFamily: "DM Sans, sans-serif" }}>
                {line.text}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <div
      className="min-h-screen w-full flex flex-col items-center justify-center overflow-hidden relative"
      style={{ background: "#f2f3fa", fontFamily: "DM Sans, sans-serif" }}
    >
      {/* Ambient glow */}
      <div
        className="absolute pointer-events-none"
        style={{
          top: "35%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: 900,
          height: 600,
          background: "radial-gradient(ellipse at center, rgba(99,102,241,0.07) 0%, transparent 65%)",
        }}
      />

      {/* Subtle dot grid */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: "radial-gradient(circle, rgba(0,0,0,0.08) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
          opacity: 0.6,
        }}
      />

      {/* Hero copy */}
      <div className="relative z-10 flex flex-col items-center text-center mb-14 px-6">
        <div
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium mb-6"
          style={{
            background: "rgba(99,102,241,0.08)",
            border: "1px solid rgba(99,102,241,0.2)",
            color: "#6366f1",
            fontFamily: "DM Sans, sans-serif",
          }}
        >
          <Zap className="w-3 h-3" />
          Now in public beta
        </div>
        <h1
          className="text-[52px] leading-[1.08] font-bold tracking-tight mb-5"
          style={{ fontFamily: "Bricolage Grotesque, sans-serif", color: "#111219", letterSpacing: "-0.03em", maxWidth: 640 }}
        >
          Where your team{"'"}s
          <br />
          <span style={{ color: "#6366f1" }}>work actually lives.</span>
        </h1>
        <p
          className="text-[17px] leading-relaxed mb-8"
          style={{ color: "rgba(0,0,0,0.45)", maxWidth: 420, fontFamily: "DM Sans, sans-serif" }}
        >
          Basepoint brings CRM, analytics, and team communication into one coherent workspace — no duct tape required.
        </p>
        <div className="flex items-center gap-3">
          <button
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all hover:opacity-90"
            style={{
              background: "#6366f1",
              color: "#fff",
              fontFamily: "DM Sans, sans-serif",
              boxShadow: "0 4px 16px rgba(99,102,241,0.3)",
            }}
          >
            Start for free
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            className="px-5 py-2.5 rounded-lg text-sm font-medium transition-all hover:bg-black/5"
            style={{ color: "rgba(0,0,0,0.45)", border: "1px solid rgba(0,0,0,0.12)", fontFamily: "DM Sans, sans-serif" }}
          >
            See how it works
          </button>
        </div>
      </div>

      {/* Window cluster */}
      <div className="relative z-10 flex-shrink-0" style={{ width: 1100, height: 500 }}>
        {/* Chat panel — left, behind main */}
        <div className="absolute" style={{ top: 40, left: 0, zIndex: 10 }}>
          <ChatPanel />
        </div>

        {/* Terminal — bottom-left, peeking out below main */}
        <div className="absolute" style={{ bottom: 0, left: 60, zIndex: 10 }}>
          <TerminalPanel />
        </div>

        {/* Main dashboard — center front */}
        <div className="absolute" style={{ top: 16, left: "50%", transform: "translateX(-50%)", zIndex: 30 }}>
          <MainDashboard />
        </div>

        {/* Video panel — right, beside main */}
        <div className="absolute" style={{ top: 40, right: 0, zIndex: 10 }}>
          <VideoPanel />
        </div>
      </div>

      {/* Bottom fade */}
      <div
        className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none"
        style={{ background: "linear-gradient(to top, #f2f3fa 0%, transparent 100%)" }}
      />
    </div>
  );
}
