import { useState } from "react";
import { motion } from "motion/react"; // used by IntegrationCard + CTA button
import {
  CreditCard,
  Calendar,
  BookOpen,
  MessageSquare,
  Zap,
  MapPin,
  Smartphone,
  Mail,
  ArrowRight,
} from "lucide-react";

// ─── Data ────────────────────────────────────────────────────────────────────

const INTEGRATIONS = [
  { id: 0, name: "Stripe",          color: "#635BFF", icon: CreditCard    },
  { id: 1, name: "Google Calendar", color: "#4285F4", icon: Calendar      },
  { id: 2, name: "QuickBooks",      color: "#2CA01C", icon: BookOpen      },
  // { id: 3, name: "Twilio SMS",      color: "#F22F46", icon: MessageSquare },
  { id: 4, name: "Zapier",          color: "#FF4A00", icon: Zap           },
  { id: 5, name: "Google Maps",     color: "#34A853", icon: MapPin        },
  { id: 6, name: "Apple Pay",       color: "#A0A0A0", icon: Smartphone    },
  { id: 7, name: "Mailchimp",       color: "#FFE01B", icon: Mail          },
] as const;

// Two rows with different starting offsets
const TOP_ROW    = [...INTEGRATIONS, ...INTEGRATIONS];
const BOTTOM_ROW = [
  ...INTEGRATIONS.slice(4),
  ...INTEGRATIONS.slice(0, 4),
  ...INTEGRATIONS.slice(4),
  ...INTEGRATIONS.slice(0, 4),
];


// ─── IntegrationCard ─────────────────────────────────────────────────────────

interface CardProps {
  id: number;
  name: string;
  color: string;
  icon: React.ElementType;
}

function IntegrationCard({ name, color, icon: Icon }: CardProps) {
  const [hovered, setHovered] = useState(false);

  return (
    <motion.div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      animate={{
        scale: hovered ? 1.03 : 1,
        borderColor: hovered ? `${color}55` : "rgba(255,255,255,0.07)",
        boxShadow: hovered
          ? `0 0 0 1px ${color}22, 0 8px 32px rgba(0,0,0,0.5)`
          : "0 0 0 0px transparent, 0 2px 8px rgba(0,0,0,0.3)",
      }}
      transition={{ duration: 0.18, ease: "easeOut" }}
      className="flex items-center gap-3.5 px-5 shrink-0 cursor-default select-none"
      style={{
        width: 200,
        height: 80,
        borderRadius: 9999,
        border: "1px solid rgba(255,255,255,0.07)",
        background: "rgba(255,255,255,0.025)",
        backdropFilter: "blur(12px)",
      }}
    >
      {/* Brand-colored icon bubble */}
      <div
        className="flex items-center justify-center shrink-0 rounded-full"
        style={{
          width: 36,
          height: 36,
          background: `${color}1A`,
          boxShadow: `0 0 14px ${color}33`,
          border: `1px solid ${color}30`,
        }}
      >
        <Icon size={15} color={color} strokeWidth={2.2} />
      </div>

      <span
        className="text-sm font-medium whitespace-nowrap tracking-tight"
        style={{ color: "rgba(255,255,255,0.58)", fontFamily: "'Plus Jakarta Sans', sans-serif" }}
      >
        {name}
      </span>
    </motion.div>
  );
}


// ─── Main component ───────────────────────────────────────────────────────────

export default function App() {
  return (
    <div
      className="min-h-screen w-full flex items-center justify-center"
      style={{ background: "#0a0a0a", fontFamily: "'Plus Jakarta Sans', sans-serif" }}
    >
      {/* Keyframe injections */}
      <style>{`
        @keyframes marquee-left {
          from { transform: translateX(0); }
          to   { transform: translateX(-50%); }
        }
        @keyframes marquee-right {
          from { transform: translateX(-50%); }
          to   { transform: translateX(0); }
        }
        .scroll-left  { animation: marquee-left  32s linear infinite; }
        .scroll-right { animation: marquee-right 32s linear infinite; }
        .marquee-zone:hover .scroll-left,
        .marquee-zone:hover .scroll-right {
          animation-play-state: paused;
        }
      `}</style>

      <section className="relative w-full py-32 overflow-hidden">

        {/* ── Header ── */}
        <div className="relative z-10 text-center px-6 mb-16">
          <p
            className="text-xs tracking-[0.28em] uppercase mb-5 font-medium"
            style={{ color: "#4bac50", fontFamily: "'JetBrains Mono', monospace" }}
          >
            Ecosystem
          </p>

          <h2
            className="text-4xl md:text-5xl font-bold tracking-tight mb-8 leading-tight"
            style={{ color: "#ffffff" }}
          >
            Plays well with the tools
            <br />
            you already run
          </h2>

          <motion.button
            whileHover={{ borderColor: "rgba(75,172,80,0.55)", background: "rgba(75,172,80,0.1)" }}
            whileTap={{ scale: 0.97 }}
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-medium transition-colors"
            style={{
              border: "1px solid rgba(75,172,80,0.28)",
              color: "#4bac50",
              background: "rgba(75,172,80,0.05)",
              fontFamily: "'Plus Jakarta Sans', sans-serif",
            }}
          >
            See all integrations
            <ArrowRight size={13} strokeWidth={2.5} />
          </motion.button>
        </div>

        {/* ── Marquee rows ── */}
        <div className="relative marquee-zone">

          {/* Edge fade masks */}
          <div
            className="absolute inset-y-0 left-0 z-10 pointer-events-none"
            style={{ width: 120, background: "linear-gradient(to right, #0a0a0a 0%, transparent 100%)" }}
          />
          <div
            className="absolute inset-y-0 right-0 z-10 pointer-events-none"
            style={{ width: 120, background: "linear-gradient(to left, #0a0a0a 0%, transparent 100%)" }}
          />

          {/* Row 1 — scrolls left */}
          <div className="overflow-hidden mb-4">
            <div className="scroll-left flex gap-4 py-3" style={{ width: "max-content" }}>
              {TOP_ROW.map((item, i) => (
                <IntegrationCard key={`t-${i}`} {...item} />
              ))}
            </div>
          </div>

          {/* Row 2 — scrolls right */}
          <div className="overflow-hidden">
            <div className="scroll-right flex gap-4 py-3" style={{ width: "max-content" }}>
              {BOTTOM_ROW.map((item, i) => (
                <IntegrationCard key={`b-${i}`} {...item} />
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
