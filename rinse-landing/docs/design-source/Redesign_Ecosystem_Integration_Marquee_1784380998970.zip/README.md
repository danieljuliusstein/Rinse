
  # Redesign Ecosystem Integration Marquee

  This is a code bundle for Redesign Ecosystem Integration Marquee. The original project is available at https://www.figma.com/design/XIjQMyhYuc0wMMjoKSwFvI/Redesign-Ecosystem-Integration-Marquee.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  