
  # Design Pricing Section

  This is a code bundle for Design Pricing Section. The original project is available at https://www.figma.com/design/yDGVs8lJGbvT3s0gTFmJiF/Design-Pricing-Section.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  