
  # Redesign Testimonials Section

  This is a code bundle for Redesign Testimonials Section. The original project is available at https://www.figma.com/design/T8yAECFurUiwHvcjrdTdai/Redesign-Testimonials-Section.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  