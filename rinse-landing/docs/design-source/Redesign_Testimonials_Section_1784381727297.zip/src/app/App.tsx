import { useEffect, useRef, useState } from "react";
import { motion } from "motion/react";
import { Play } from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  city: string;
  quote: string;
  stars: number;
  avatar: string;
  featured?: boolean;
  hasVideo?: boolean;
}

// ─── Data ────────────────────────────────────────────────────────────────────

const TESTIMONIALS: Testimonial[] = [
  {
    id: "marcus",
    name: "Marcus Rivera",
    role: "Owner",
    company: "Apex Mobile Detailing",
    city: "Los Angeles, CA",
    quote:
      "We were drowning in spreadsheets — separate sheets for invoicing, scheduling, follow-ups. The moment we moved to Rinse, everything collapsed into one place. Six bookings a week became twenty-two in under ninety days. I stopped doing admin at midnight.",
    stars: 5,
    avatar:
      "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=88&h=88&fit=crop&auto=format",
    featured: true,
  },
  {
    id: "dominique",
    name: "Dominique Osei",
    role: "CEO",
    company: "Prestige Auto Spa",
    city: "Atlanta, GA",
    quote:
      "Route optimization alone saves us two hours every single day. That's ten hours a week we put back into client work, not logistics. Our techs actually show up on time now — customers noticed before we even told them.",
    stars: 5,
    avatar:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=88&h=88&fit=crop&auto=format",
    hasVideo: true,
  },
  {
    id: "priya",
    name: "Priya Nair",
    role: "Founder",
    company: "Shine Theory Detailing",
    city: "Austin, TX",
    quote:
      "Running solo used to mean flying blind. Now my dashboards give me a real picture of revenue, retention, and where I'm losing jobs. It feels like I have a full operations team backing me up.",
    stars: 5,
    avatar:
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=88&h=88&fit=crop&auto=format",
  },
];

// ─── Stat bar data ────────────────────────────────────────────────────────────

interface Stat {
  value: number;
  suffix: string;
  label: string;
  decimals?: number;
}

const STATS: Stat[] = [
  { value: 4200, suffix: "+", label: "detailers on Rinse" },
  { value: 2.1, suffix: "M", label: "jobs completed", decimals: 1 },
  { value: 4.9, suffix: " ★", label: "avg rating", decimals: 1 },
];

// ─── Count-up hook ────────────────────────────────────────────────────────────

function useCountUp(target: number, decimals = 0, active: boolean) {
  const [count, setCount] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    if (!active) return;
    const duration = 1600;
    const start = performance.now();

    function step(now: number) {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      // ease-out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(parseFloat((eased * target).toFixed(decimals)));
      if (progress < 1) rafRef.current = requestAnimationFrame(step);
    }

    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [active, target, decimals]);

  return count;
}

// ─── StatItem ─────────────────────────────────────────────────────────────────

function StatItem({ stat, active }: { stat: Stat; active: boolean }) {
  const count = useCountUp(stat.value, stat.decimals ?? 0, active);
  const display = stat.decimals ? count.toFixed(stat.decimals) : Math.floor(count).toLocaleString();

  return (
    <div className="flex flex-col items-center gap-1 px-8 first:pl-0 last:pr-0">
      <span className="font-mono text-4xl font-bold tracking-tight text-neutral-900">
        {display}
        {stat.suffix}
      </span>
      <span className="text-xs font-medium uppercase tracking-widest text-black/35">
        {stat.label}
      </span>
    </div>
  );
}

// ─── Stars ────────────────────────────────────────────────────────────────────

function Stars({ count }: { count: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: count }).map((_, i) => (
        <svg key={i} width="14" height="14" viewBox="0 0 14 14" fill="#4bac50">
          <path d="M7 1l1.545 3.13L12 4.635l-2.5 2.435.59 3.44L7 8.885l-3.09 1.625L4.5 7.07 2 4.635l3.455-.505z" />
        </svg>
      ))}
    </div>
  );
}

// ─── TestimonialCard ──────────────────────────────────────────────────────────

function TestimonialCard({ t, index }: { t: Testimonial; index: number }) {
  const featured = t.featured;

  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.52, delay: index * 0.08, ease: [0.22, 1, 0.36, 1] }}
      className={[
        "rounded-2xl p-6 shadow-sm break-inside-avoid mb-4",
        featured
          ? "border-l-4 border-[#4bac50] bg-[#4bac50]/[0.04] border border-black/[0.06]"
          : "bg-white border border-black/[0.06]",
      ].join(" ")}
    >
      {/* Stars */}
      <Stars count={t.stars} />

      {/* Quote */}
      <p
        className={[
          "mt-3 leading-relaxed text-neutral-700",
          featured ? "text-lg font-medium" : "text-sm",
        ].join(" ")}
      >
        &ldquo;{t.quote}&rdquo;
      </p>

      {/* Video pill */}
      {t.hasVideo && (
        <button className="mt-4 inline-flex items-center gap-1.5 rounded-full border border-[#4bac50] px-3 py-1.5 text-xs font-semibold text-[#4bac50] hover:bg-[#4bac50]/[0.06] transition-colors">
          <Play size={11} strokeWidth={2.5} className="fill-[#4bac50]" />
          Watch story →
        </button>
      )}

      {/* Author */}
      <div className="mt-5 flex items-center gap-3">
        <img
          src={t.avatar}
          alt={t.name}
          width={44}
          height={44}
          className={[
            "size-11 rounded-full object-cover bg-neutral-100",
            featured ? "ring-2 ring-[#4bac50]/40 ring-offset-1" : "",
          ].join(" ")}
        />
        <div>
          <p className="text-sm font-semibold text-neutral-900">{t.name}</p>
          <p className="text-xs text-black/40">
            {t.role}, {t.company} · {t.city}
          </p>
        </div>
      </div>
    </motion.div>
  );
}

// ─── Main Section ─────────────────────────────────────────────────────────────

export default function App() {
  const statRef = useRef<HTMLDivElement>(null);
  const [statsActive, setStatsActive] = useState(false);

  useEffect(() => {
    if (!statRef.current) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setStatsActive(true);
          observer.disconnect();
        }
      },
      { threshold: 0.4 }
    );
    observer.observe(statRef.current);
    return () => observer.disconnect();
  }, []);

  // Distribute into 3 columns: featured (Marcus) leads col 1
  const col1 = [TESTIMONIALS[0]]; // Marcus – featured
  const col2 = [TESTIMONIALS[1]]; // Dominique
  const col3 = [TESTIMONIALS[2]]; // Priya

  const columns = [col1, col2, col3];

  return (
    <div
      className="min-h-screen bg-white py-24 px-6"
      style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
    >
      <div className="mx-auto max-w-6xl">

        {/* Eyebrow */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.45 }}
          className="mb-5 flex items-center gap-2"
        >
          <span className="font-mono text-xs font-semibold uppercase tracking-widest text-[#4bac50]">
            Social proof
          </span>
          <span className="h-px w-8 bg-[#4bac50]/40" />
        </motion.div>

        {/* Headline */}
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.06 }}
          className="mb-14"
        >
          <h2 className="text-4xl font-bold tracking-tight text-neutral-900 leading-tight sm:text-5xl">
            Built by operators,
          </h2>
          <h2 className="text-4xl font-bold tracking-tight text-neutral-900/25 leading-tight sm:text-5xl">
            for operators.
          </h2>
        </motion.div>

        {/* Stat bar */}
        <div
          ref={statRef}
          className="mb-16 flex flex-wrap items-center justify-start gap-y-6 divide-x divide-black/10"
        >
          {STATS.map((stat) => (
            <StatItem key={stat.label} stat={stat} active={statsActive} />
          ))}
        </div>

        {/* Masonry grid — CSS columns on desktop, single column on mobile */}
        <div className="hidden md:grid md:grid-cols-3 md:gap-4 md:items-start">
          {columns.map((col, ci) => (
            <div key={ci} className="flex flex-col gap-4">
              {col.map((t, ti) => (
                <TestimonialCard key={t.id} t={t} index={ci + ti} />
              ))}
            </div>
          ))}
        </div>

        {/* Mobile: single column */}
        <div className="flex flex-col gap-4 md:hidden">
          {TESTIMONIALS.map((t, i) => (
            <TestimonialCard key={t.id} t={t} index={i} />
          ))}
        </div>
      </div>
    </div>
  );
}
