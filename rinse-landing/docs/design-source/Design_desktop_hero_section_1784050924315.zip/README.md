
  # Design desktop hero section

  This is a code bundle for Design desktop hero section. The original project is available at https://www.figma.com/design/7ZZdTX1lQYUnyvjzmUT0I2/Design-desktop-hero-section.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  